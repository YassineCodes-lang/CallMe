import React from 'react';
import {BrowserRouter as Router,Routes,Route} from 'react-router-dom';
import './App.css';
import Home from './componens/Home';
import Call from './componens/Call';

function App() {
  return (
    <Router>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/room/:roomID' element={<Call/>}/>
      </Routes>
    </Router>
  );
}

export default App;
