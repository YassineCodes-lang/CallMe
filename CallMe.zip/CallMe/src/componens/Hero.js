import React,{useState} from "react";
import pic from '../pics/Img3.jpg'
const Hero = () => {
    const [input,setInput] = useState('')
    const submitHandler = (e) =>{
        e.preventDefault();
        if(input){
            window.location.href = `room/${input}`
        }
    }
    return (
        <div>
            <div className="bg-light">
                <section className="py-5 py-lg-4">
                    <div className="container">
                        <div className="row align-items-center g-5">
                            <div className="col-lg-6">
                                <div className="text-center text-lg-start">
                                    <h1 className="display-4 fw-bold text-dark">Meet with your friends</h1>
                                    <p className="mt-3 lead text-secondary">Start a free conferance call with your friends, team members.No sign up required.</p>


                                    <form action="#" method="POST" className="mt-4">
                                        <div className="input-group">
                                            <input type="text" value={input} onChange={(e)=>setInput(e.target.value)} className="form-control rounded-start border-secondary" placeholder="Enter Your Room Id" required />
                                            <button className="btn btn-primary text-white fw-bold px-4 rounded-end" onClick={submitHandler}>Join Us Now</button>
                                        </div>
                                    </form>
                                </div>


                                <div className="d-flex justify-content-center justify-content-lg-start align-items-center mt-4 gap-5">

                                    <div className="text-center text-lg-start">
                                        <h2 className="fw-bold mb-0">2050</h2>
                                        <p className="text-muted small mb-0">Projects<br />Completed</p>
                                    </div>

                                    <div className="d-none d-sm-block">
                                        <svg className="text-muted" width="16" height="39" viewBox="0 0 16 39" fill="none" stroke="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <line x1="0.72265" y1="10.584" x2="15.7226" y2="0.583975"></line>
                                            <line x1="0.72265" y1="17.584" x2="15.7226" y2="7.58398"></line>
                                            <line x1="0.72265" y1="24.584" x2="15.7226" y2="14.584"></line>
                                            <line x1="0.72265" y1="31.584" x2="15.7226" y2="21.584"></line>
                                            <line x1="0.72265" y1="38.584" x2="15.7226" y2="28.584"></line>
                                        </svg>
                                    </div>


                                    <div className="text-center text-lg-start">
                                        <h2 className="fw-bold mb-0">$5M+</h2>
                                        <p className="text-muted small mb-0">Investment<br />Supported</p>
                                    </div>
                                </div>
                            </div>


                            <div className="col-lg-6">
                                <img className="img-fluid" src={pic} alt="Innovative Team" />
                            </div>
                        </div>
                    </div>
                </section>
            </div>

        </div>
    )
}

export default Hero;