import React from "react";

const PartnerLogo = () => {
    return (
        <div>
            <section className="position-relative py-5 overflow-hidden bg-light">
                <div className="container">
                    <div className="row align-items-center">

                        <div className="col-xl-6 text-center text-xl-start px-4">
                            <h2 className="display-5 fw-bold text-dark">
                                Customers and brands love using Rareblocks
                            </h2>
                            <p className="mt-4 lead text-secondary">
                                Lorem ipsum dolor sit amet, consectetur adipis elit. Sit enim nec,
                                proin faucibus nibh et sagittis.
                            </p>
                        </div>


                        <div className="col-xl-6 mt-5 mt-xl-0 position-relative">

                            <div className="position-absolute top-50 start-50 translate-middle w-100 h-100 rounded-3 bg-gradient opacity-30 blur"
                                style={{background: `linear-gradient(
            90deg, 
            #44ff9a -0.55%, 
            #44b0ff 22.86%, 
            #8b44ff 48.36%, 
            #ff6644 73.33%, 
            #ebff70 99.34%)`}}>
                            </div>

                            <div className="position-relative">

                                <div className="row row-cols-1 row-cols-sm-3 g-4">

                                    <div className="col">
                                        <div className="bg-white p-3 rounded shadow text-center">
                                            <img
                                                className="img-fluid"
                                                src="https://cdn.rareblocks.xyz/collection/clarity/images/brands/3/logo-vertex.svg"
                                                alt="Vertex Logo"
                                            />
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="bg-white p-3 rounded shadow text-center">
                                            <img
                                                className="img-fluid"
                                                src="https://cdn.rareblocks.xyz/collection/clarity/images/brands/3/logo-martino.svg"
                                                alt="Martino Logo"
                                            />
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="bg-white p-3 rounded shadow text-center">
                                            <img
                                                className="img-fluid"
                                                src="https://cdn.rareblocks.xyz/collection/clarity/images/brands/3/logo-squarestone.svg"
                                                alt="Squarestone Logo"
                                            />
                                        </div>
                                    </div>


                                    <div className="col">
                                        <div className="bg-white p-3 rounded shadow text-center">
                                            <img
                                                className="img-fluid"
                                                src="https://cdn.rareblocks.xyz/collection/clarity/images/brands/3/logo-waverio.svg"
                                                alt="Waverio Logo"
                                            />
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="bg-white p-3 rounded shadow text-center">
                                            <img
                                                className="img-fluid"
                                                src="https://cdn.rareblocks.xyz/collection/clarity/images/brands/3/logo-fireli.svg"
                                                alt="Fireli Logo"
                                            />
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="bg-white p-3 rounded shadow text-center">
                                            <img
                                                className="img-fluid"
                                                src="https://cdn.rareblocks.xyz/collection/clarity/images/brands/3/logo-virogan.svg"
                                                alt="Virogan Logo"
                                            />
                                        </div>
                                    </div>


                                    <div className="col">
                                        <div className="bg-white p-3 rounded shadow text-center">
                                            <img
                                                className="img-fluid"
                                                src="https://cdn.rareblocks.xyz/collection/clarity/images/brands/3/logo-aromix.svg"
                                                alt="Aromix Logo"
                                            />
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="bg-white p-3 rounded shadow text-center">
                                            <img
                                                className="img-fluid"
                                                src="https://cdn.rareblocks.xyz/collection/clarity/images/brands/3/logo-natroma.svg"
                                                alt="Natroma Logo"
                                            />
                                        </div>
                                    </div>
                                    <div className="col">
                                        <div className="bg-white p-3 rounded shadow text-center">
                                            <img
                                                className="img-fluid"
                                                src="https://cdn.rareblocks.xyz/collection/clarity/images/brands/3/logo-waverio-2.svg"
                                                alt="Waverio 2 Logo"
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div
                    className="position-absolute top-0 start-0 w-100 h-100 bg-gradient"
                    style={{background: `linear-gradient(to bottom, transparent, #f8f9fa);`}}>
                </div>
            </section>

        </div>
    )
}

export default PartnerLogo;