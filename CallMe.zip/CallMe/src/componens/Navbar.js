import React from "react";

const Navbar = () => {
    return (

            <header className="bg-white border-bottom">
                <div className="container">
                    <nav className="navbar navbar-expand-lg navbar-light py-3">

                        <a className="navbar-brand" href="#">
                            <h1 className="d-inline-block align-top" style={{'height': '40px'}}><span style={{'background':'black','color':'white','borderRadius':'3px'}}>Call</span>Me</h1>
                        </a>


                        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>


                        <div className="collapse navbar-collapse" id="navbarNav">
                            <ul className="navbar-nav ms-auto mb-2 mb-lg-0">
                                <li className="nav-item">
                                    <a className="nav-link text-black" href="#">Features</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link text-black" href="#">Solutions</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link text-black" href="#">Resources</a>
                                </li>
                                <li className="nav-item">
                                    <a className="nav-link text-black" href="#">Pricing</a>
                                </li>
                            </ul>

                            <a href="#" className="btn btn-primary ms-lg-3">Get Started</a>
                        </div>
                    </nav>
                </div>
            </header>

    
    )
}

export default Navbar;