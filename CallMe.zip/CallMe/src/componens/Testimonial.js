import React from "react";

const Testimonial = () => {
    return (
        <div>
            <section className="py-5 bg-light">
                <div className="container">
                    <div className="text-center mb-5">
                        <p className="text-secondary">3,421 people loved our amazing services</p>
                        <h2 className="fw-bold">See what our awesome clients have to say</h2>
                    </div>

                    <div className="text-center mb-4">
                        <a href="#" className="text-decoration-none fw-bold border-bottom border-dark pb-1 text-dark">Check all 3,421 reviews</a>
                    </div>

                    <div className="row g-4">
                        <div className="col-md-4">
                            <div className="card shadow h-100">
                                <div className="card-body">
                                    <div className="d-flex mb-3">
                                        <i className="bi bi-star-fill text-warning me-1"></i>
                                        <i className="bi bi-star-fill text-warning me-1"></i>
                                        <i className="bi bi-star-fill text-warning me-1"></i>
                                    </div>
                                    <blockquote className="blockquote">
                                        <p className="mb-0">“Absolutely amazing! Their services exceeded my expectations. I'm thrilled with the results.”</p>
                                    </blockquote>
                                </div>
                                <div className="card-footer bg-white border-0 d-flex align-items-center">
                                    <img src="https://cdn.rareblocks.xyz/collection/clarity/images/testimonial/4/avatar-male-1.png" alt="Avatar" className="rounded-circle me-3" width="45" height="45" />
                                    <div>
                                        <h6 className="mb-0 fw-bold">Michael Kim</h6>
                                        <small className="text-muted">Software Engineer</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="card shadow h-100">
                                <div className="card-body">
                                    <div className="d-flex mb-3">
                                        <i className="bi bi-star-fill text-warning me-1"></i>
                                        <i className="bi bi-star-fill text-warning me-1"></i>
                                    </div>
                                    <blockquote className="blockquote">
                                        <p className="mb-0">“Impressed beyond words! Their professionalism and attention to detail are unmatched. I highly recommend them.”</p>
                                    </blockquote>
                                </div>
                                <div className="card-footer bg-white border-0 d-flex align-items-center">
                                    <img src="https://cdn.rareblocks.xyz/collection/clarity/images/testimonial/4/avatar-male-2.png" alt="Avatar" className="rounded-circle me-3" width="45" height="45" />
                                    <div>
                                        <h6 className="mb-0 fw-bold">Melissa Reynolds</h6>
                                        <small className="text-muted">UX Designer</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="col-md-4">
                            <div className="card shadow h-100">
                                <div className="card-body">
                                    <div className="d-flex mb-3">
                                        <i className="bi bi-star-fill text-warning me-1"></i>
                                        <i className="bi bi-star-fill text-warning me-1"></i>
                                        <i className="bi bi-star-fill text-warning me-1"></i>
                                    </div>
                                    <blockquote className="blockquote">
                                        <p className="mb-0">“Outstanding experience! Their support team is exceptional and the quality of their work is top-notch. I'm a delighted customer.”</p>
                                    </blockquote>
                                </div>
                                <div className="card-footer bg-white border-0 d-flex align-items-center">
                                    <img src="https://cdn.rareblocks.xyz/collection/clarity/images/testimonial/4/avatar-female.png" alt="Avatar" className="rounded-circle me-3" width="45" height="45" />
                                    <div>
                                        <h6 className="mb-0 fw-bold">Sarah Morgan</h6>
                                        <small className="text-muted">Creative Director</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>




        </div>
    )
}

export default Testimonial;